
#ifndef GYROSCOPIC_SETUP_H
#define GYROSCOPIC_SETUP_H

class CommonExampleInterface* GyroscopicCreateFunc(struct CommonExampleOptions& options);

#endif  //GYROSCOPIC_SETUP_H
