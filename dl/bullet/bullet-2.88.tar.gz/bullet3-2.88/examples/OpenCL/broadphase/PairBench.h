#ifndef PAIR_BENCH_H
#define PAIR_BENCH_H

class CommonExampleInterface* PairBenchOpenCLCreateFunc(struct CommonExampleOptions& options);

#endif
