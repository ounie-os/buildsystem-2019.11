# ------------------------------------------------------------------------------
#  Copyright (C) 2012, Robert Johansson <rob@raditex.nu>, Raditex Control AB
#  All rights reserved.
# 
#  rSCADA 
#  http://www.rSCADA.se
#  info@raditex.nu
# 
# ------------------------------------------------------------------------------

debuild -i -us -uc -b 
#sudo pbuilder build $(NAME)_$(VERSION)-1.dsc
