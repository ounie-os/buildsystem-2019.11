# rtlwifi-8192cu
The code come from linux kernel 4.18.10 drivers/net/wireless/realtek/rtlwifi
