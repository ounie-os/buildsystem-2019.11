.. PyModbus documentation master file, created by
   sphinx-quickstart on Wed Dec 20 12:31:10 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyModbus's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme.rst
   changelog.rst
   source/library/REPL
   source/example/modules.rst
   source/library/modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
