==================================================
Message Generator Example
==================================================
.. literalinclude:: ../../../examples/contrib/message_generator.py