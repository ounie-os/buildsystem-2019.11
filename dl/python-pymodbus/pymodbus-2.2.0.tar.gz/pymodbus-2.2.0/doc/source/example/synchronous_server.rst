==================================================
Synchronous Server Example
==================================================
.. literalinclude:: ../../../examples/common/synchronous_server.py