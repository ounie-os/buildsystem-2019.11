==================================================
Async Tornado Client Example
==================================================
.. literalinclude:: ../../../examples/common/async_tornado_client.py