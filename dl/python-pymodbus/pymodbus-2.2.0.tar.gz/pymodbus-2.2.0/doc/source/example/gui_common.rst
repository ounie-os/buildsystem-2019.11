==================================================
Gui Common Example
==================================================
.. literalinclude:: ../../../examples/gui/gui_common.py