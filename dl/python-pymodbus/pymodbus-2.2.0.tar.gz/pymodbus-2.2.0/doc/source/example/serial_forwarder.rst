==================================================
Serial Forwarder Example
==================================================
.. literalinclude:: ../../../examples/contrib/serial_forwarder.py