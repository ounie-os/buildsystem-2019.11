==================================================
Modbus Logging Example
==================================================
.. literalinclude:: ../../../examples/common/modbus_logging.py