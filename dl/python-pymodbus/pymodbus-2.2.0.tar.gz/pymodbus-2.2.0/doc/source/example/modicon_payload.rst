==================================================
Modicon Payload Example
==================================================
.. literalinclude:: ../../../examples/contrib/modicon_payload.py