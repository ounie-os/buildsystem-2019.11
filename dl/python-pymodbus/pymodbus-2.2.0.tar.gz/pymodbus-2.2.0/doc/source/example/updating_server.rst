==================================================
Updating Server Example
==================================================
.. literalinclude:: ../../../examples/common/updating_server.py