==================================================
Async Asyncio Client Example
==================================================
.. literalinclude:: ../../../examples/common/async_asyncio_client.py