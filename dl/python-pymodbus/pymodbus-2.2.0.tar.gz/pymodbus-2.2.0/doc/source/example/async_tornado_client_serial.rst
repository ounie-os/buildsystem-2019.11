==================================================
Async Tornado Client Serial Example
==================================================
.. literalinclude:: ../../../examples/common/async_tornado_client_serial.py