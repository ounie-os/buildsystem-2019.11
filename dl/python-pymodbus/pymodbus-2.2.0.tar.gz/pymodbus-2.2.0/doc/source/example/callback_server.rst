===========================
Callback Server Example
===========================
.. literalinclude:: ../../../examples/common/callback_server.py