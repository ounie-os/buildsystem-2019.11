==================================================
Changing Framers Example
==================================================
.. literalinclude:: ../../../examples/common/changing_framers.py