==================================================
Async Twisted Client Serial Example
==================================================
.. literalinclude:: ../../../examples/common/async_twisted_client_serial.py