==================================================
Synchronous Client Ext Example
==================================================
.. literalinclude:: ../../../examples/common/synchronous_client_ext.py