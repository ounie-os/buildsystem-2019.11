==================================================
Bcd Payload Example
==================================================
.. literalinclude:: ../../../examples/contrib/bcd_payload.py