==================================================
Custom Datablock Example
==================================================
.. literalinclude:: ../../../examples/common/custom_datablock.py