==================================================
Message Parser Example
==================================================
.. literalinclude:: ../../../examples/contrib/message_parser.py