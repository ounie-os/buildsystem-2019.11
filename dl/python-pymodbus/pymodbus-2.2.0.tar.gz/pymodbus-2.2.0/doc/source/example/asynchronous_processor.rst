==================================================
Asynchronous Processor Example
==================================================
.. literalinclude:: ../../../examples/common/asynchronous_processor.py