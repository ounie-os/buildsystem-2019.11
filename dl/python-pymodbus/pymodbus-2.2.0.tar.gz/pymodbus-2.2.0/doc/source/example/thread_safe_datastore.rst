==================================================
Thread Safe Datastore Example
==================================================
.. literalinclude:: ../../../examples/contrib/thread_safe_datastore.py