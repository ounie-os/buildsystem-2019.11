==================================================
Dbstore Update Server Example
==================================================
.. literalinclude:: ../../../examples/common/dbstore_update_server.py