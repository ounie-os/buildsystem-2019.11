dbus.decorators module
----------------------

.. automodule:: dbus.decorators
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
