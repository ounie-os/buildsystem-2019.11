===============
Release history
===============

.. include:: ../NEWS
